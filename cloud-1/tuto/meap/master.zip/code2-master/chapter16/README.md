# Imagery

![Imagery](./imagery.png?raw=true "Imagery")

To try Imagery app create a CloudFormation stack based on the template https://s3.amazonaws.com/awsinaction-code2/chapter16/template.yaml
