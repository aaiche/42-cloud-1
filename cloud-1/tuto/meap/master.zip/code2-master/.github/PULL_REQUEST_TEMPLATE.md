Please run `yamllint folder/template.yaml` and `aws cloudformation validate-template --template-body file://folder/template.yaml` before
